# Minha Estante

Aplicativo Minha Estante - Organizador de Mangá.

A versão web está em `www/index.html` e é empacotada para Android com Capacitor.

O workflow `.github/workflows/build-apk.yml` gera automaticamente um APK de teste pelo GitHub Actions.
